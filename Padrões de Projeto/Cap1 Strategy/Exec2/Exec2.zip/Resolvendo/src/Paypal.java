public class Paypal implements Strategy{
	
}