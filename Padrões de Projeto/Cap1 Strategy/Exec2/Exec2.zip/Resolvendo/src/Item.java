public class Item{
	public Item(String cod, double valor) {
		this.cod = cod;
		this.valor = valor;
	}
	public String cod;
	public double valor;
}