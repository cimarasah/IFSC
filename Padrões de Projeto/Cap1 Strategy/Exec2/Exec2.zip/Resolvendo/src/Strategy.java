
public interface Strategy {

}
